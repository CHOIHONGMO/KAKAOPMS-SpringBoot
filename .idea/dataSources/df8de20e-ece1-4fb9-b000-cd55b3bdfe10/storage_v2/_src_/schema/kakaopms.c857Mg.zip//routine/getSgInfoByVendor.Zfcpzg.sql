create
    definer = kakaopms@`%` function getSgInfoByVendor(P_GATE_CD varchar(100), P_VENDOR_CD varchar(100),
                                                      P_INFO_TYPE varchar(10)) returns varchar(500) deterministic
BEGIN
     
    DECLARE value  varchar(500);
    
    SELECT INSERT ((SELECT ', ' + (CASE WHEN P_INFO_TYPE = 'NM' THEN SGMT.SG_NM
                                        WHEN P_INFO_TYPE = 'NUM' THEN SGMT.SG_NUM
                                        ELSE SGMT.SG_NUM END) 
                             FROM STOCSGMT SGMT
                            WHERE SGMT.GATE_CD = P_GATE_CD
                              AND SGMT.SG_NUM IN (SELECT SGVN.SG_NUM 
                                                    FROM STOCSGVN SGVN
                                                   WHERE SGVN.GATE_CD   = P_GATE_CD
                                                     AND SGVN.VENDOR_CD = P_VENDOR_CD
                                                     AND SGVN.DEL_FLAG  = '0')
                              AND SGMT.DEL_FLAG = '0'
                            ), 1, 2, '')INTO value;

    RETURN value;

END;

