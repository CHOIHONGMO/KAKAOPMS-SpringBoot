create
    definer = kakaopms@`%` function getToChar(P_DATE datetime, P_TYPE varchar(30)) returns varchar(50) deterministic
BEGIN
    DECLARE returnVal varchar(500);

    SELECT CASE WHEN UPPER(P_TYPE) = 'MM' or P_TYPE = '%m'  THEN DATE_FORMAT(P_DATE, '%m')
                WHEN UPPER(P_TYPE) = 'DD' or P_TYPE = '%d'  THEN DATE_FORMAT(P_DATE, '%d')
                WHEN UPPER(P_TYPE) = 'YY' or P_TYPE = '%Y'  THEN DATE_FORMAT(P_DATE, '%y')
                WHEN UPPER(P_TYPE) = 'YYYY' or P_TYPE = '%Y'    THEN DATE_FORMAT(P_DATE, '%Y')
                WHEN UPPER(P_TYPE) = 'YYYYMM' or P_TYPE = '%Y/%m'   THEN DATE_FORMAT(P_DATE, '%Y%m')
                WHEN UPPER(P_TYPE) = 'YYYY/MM' or P_TYPE = '%Y/%m'  THEN DATE_FORMAT(P_DATE, '%Y/%m')
                WHEN UPPER(P_TYPE) = 'YYYYMMDD' or P_TYPE = '%Y%m%d' THEN DATE_FORMAT(P_DATE, '%Y%m%d')
                WHEN UPPER(P_TYPE) = 'YYYY/MM/DD' or P_TYPE = '%Y/%m/%d'    THEN DATE_FORMAT(P_DATE, '%Y/%m/%d')
                WHEN UPPER(P_TYPE) = 'YYYY-MM-DD' or P_TYPE = '%Y-%m-%d'    THEN DATE_FORMAT(P_DATE, '%Y-%m-%d')
                WHEN UPPER(P_TYPE) = 'YYYY.MM.DD' or P_TYPE = '%Y.%m.%d'    THEN DATE_FORMAT(P_DATE, '%Y.%m.%d')
                WHEN UPPER(P_TYPE) = 'YYYY/MM/DD HH24:MI' or P_TYPE = '%Y/%m/%d %H:%i'  THEN DATE_FORMAT(P_DATE, '%Y/%m/%d %H:%i')
                WHEN UPPER(P_TYPE) = 'YYYY-MM-DD HH24:MI' or P_TYPE = '%Y-%m-%d %H:%i'  THEN DATE_FORMAT(P_DATE, '%Y-%m-%d %H:%i')
                WHEN UPPER(P_TYPE) = 'YYYY.MM.DD HH24:MI' or P_TYPE = '%Y.%m.%d %H:%i'  THEN DATE_FORMAT(P_DATE, '%Y.%m.%d %H:%i')
                WHEN UPPER(P_TYPE) = 'YYYY/MM/DD HH24:MI:SS' or P_TYPE = '%Y/%m/%d %H:%i:%s'    THEN DATE_FORMAT(P_DATE, '%Y/%m/%d %H:%i:%s')
                WHEN UPPER(P_TYPE) = 'YYYY-MM-DD HH24:MI:SS' or P_TYPE = '%Y-%m-%d %H:%i:%s'    THEN DATE_FORMAT(P_DATE, '%Y-%m-%d %H:%i:%s')
                WHEN UPPER(P_TYPE) = 'YYYY.MM.DD HH24:MI:SS' or P_TYPE = '%Y.%m.%d %H:%i:%s'    THEN DATE_FORMAT(P_DATE, '%Y.%m.%d %H:%i:%s')
           END INTO returnVal; 

    RETURN returnVal;
END;

