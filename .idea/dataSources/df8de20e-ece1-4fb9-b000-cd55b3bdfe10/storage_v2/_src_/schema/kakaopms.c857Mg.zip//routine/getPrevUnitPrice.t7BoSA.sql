create
    definer = kakaopms@`%` function getPrevUnitPrice(P_GATE_CD varchar(100), P_APPLY_COM varchar(100),
                                                     P_VENDOR_CD varchar(100),
                                                     P_ITEM_CD varchar(100)) returns decimal deterministic
BEGIN

    DECLARE returnVal  numeric;
    
    SELECT  A.CONT_UNIT_PRICE into returnVal
      FROM (
        SELECT
             CONT_UNIT_PRICE
            ,CONT_NO, ITEM_CD
            ,ROW_NUMBER() OVER(ORDER BY CONT_NO DESC) AS ROWNUM
          FROM STOYINFO
         WHERE GATE_CD = P_GATE_CD
           AND APPLY_COM = P_APPLY_COM
           AND VENDOR_CD = P_VENDOR_CD
           AND ITEM_CD = P_ITEM_CD
      ) A limit 1;
    
    RETURN returnVal;
END;

