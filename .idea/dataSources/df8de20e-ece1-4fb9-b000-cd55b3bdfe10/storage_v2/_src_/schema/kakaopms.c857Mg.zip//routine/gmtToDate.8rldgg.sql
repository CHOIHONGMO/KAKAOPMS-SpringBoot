create
    definer = kakaopms@`%` function gmtToDate(P_DATE varchar(100), P_USER_GMT_CD varchar(100),
                                              P_SYSTEM_GMT_CD varchar(100),
                                              P_DATE_FORMAT varchar(100)) returns varchar(100) deterministic
BEGIN
    DECLARE returnVal varchar(100);
   
  SELECT getGmtDate(cast(concat(substring(P_DATE,1,4), '-', substring(P_DATE,5,2), '-', substring(P_DATE,7,2), ' ', '23:59:59') as datetime), P_USER_GMT_CD, P_SYSTEM_GMT_CD, P_DATE_FORMAT)
    INTO returnVal
    FROM DUAL;
     
    RETURN returnVal;
END;

