create
    definer = kakaopms@`%` function getCtrlName(P_GATE_CD varchar(10), P_BUYER_CD varchar(20), P_CTRL_CD varchar(20),
                                                P_LANG_CD varchar(20)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);
    
    SELECT
         CASE
                WHEN P_LANG_CD = 'EN'
                THEN IFNULL(CTRL_NM_ENG, CTRL_NM)
                ELSE CTRL_NM
         END INTO returnVal
    FROM   STOCBACO
    WHERE  GATE_CD  = P_GATE_CD
    AND    BUYER_CD = P_BUYER_CD
    AND    CTRL_CD  = P_CTRL_CD;
    
    RETURN returnVal;
END;

