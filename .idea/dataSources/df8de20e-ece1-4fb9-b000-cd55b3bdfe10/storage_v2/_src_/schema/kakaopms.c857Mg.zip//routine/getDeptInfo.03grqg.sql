create
    definer = kakaopms@`%` function getDeptInfo(gateCd varchar(10), buyerCd varchar(20), deptCd varchar(20),
                                                infoType varchar(20)) returns varchar(2000) deterministic
BEGIN

    DECLARE returnVal varchar(2000);
    
    SELECT CASE WHEN infoType = 'DEPT_NM' THEN DEPT_NM
                WHEN infoType = 'DEPT_NM_ENG' THEN DEPT_NM_ENG
                WHEN infoType = 'PARENT_DEPT_CD' THEN PARENT_DEPT_CD
                WHEN infoType = 'ADDR' THEN ADDR
                WHEN infoType = 'TEL_NUM' THEN TEL_NUM
                WHEN infoType = 'FAX_NUM' THEN FAX_NUM
                WHEN infoType = 'ADDR_ENG' THEN ADDR_ENG
                WHEN infoType = 'DEPT_IRS_NUM' THEN DEPT_IRS_NUM
                WHEN infoType = 'DEPT_CEO_NM' THEN DEPT_CEO_NM
                WHEN infoType = 'DEPT_CEO_BUSINESS_TYPE' THEN DEPT_CEO_BUSINESS_TYPE
                WHEN infoType = 'DEPT_CEO_INDUSTRY_TYPE' THEN DEPT_CEO_INDUSTRY_TYPE
                ELSE ''
             END INTO returnVal
      FROM STOCOGDP
     WHERE GATE_CD  = gateCd
       AND BUYER_CD = buyerCd
       AND DEPT_CD  = deptCd
       AND DEL_FLAG = '0'
     LIMIT 1;
      
    RETURN returnVal;
END;

