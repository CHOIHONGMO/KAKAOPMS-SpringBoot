create
    definer = kakaopms@`%` function getRegionInfoByVendor(P_GATE_CD varchar(100), P_VENDOR_CD varchar(100),
                                                          P_INFO_TYPE varchar(10),
                                                          P_LANG_CD varchar(10)) returns varchar(500) deterministic
BEGIN
     
    DECLARE value  VARCHAR(500);
    
    SELECT INSERT((SELECT ', ' + (CASE WHEN P_INFO_TYPE = 'CD' THEN VNRG.REGION_CD
                                               WHEN P_INFO_TYPE = 'NM' THEN getCodeName(GATE_CD, 'MP005', VNRG.REGION_CD, P_LANG_CD)
                                               ELSE VNRG.REGION_CD END) 
                             FROM STOCVNRG VNRG
                            WHERE VNRG.GATE_CD = P_GATE_CD
                              AND VNRG.VENDOR_CD = P_VENDOR_CD
                              AND VNRG.DEL_FLAG = '0'
                            ), 1, 2, '') into value;

    RETURN value;

END;

