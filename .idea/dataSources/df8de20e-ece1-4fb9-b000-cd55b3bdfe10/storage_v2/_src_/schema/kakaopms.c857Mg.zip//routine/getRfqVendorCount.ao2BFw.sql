create
    definer = kakaopms@`%` function getRfqVendorCount(P_GATE_CD varchar(10), P_RFQ_NUM varchar(30), P_RFQ_CNT decimal) returns varchar(100) deterministic
BEGIN

    DECLARE returnVal varchar(100);

    SELECT  RTRIM(CAST((SELECT ifnull(MAX(A.ROWNUM), 0) FROM (
                            SELECT ROW_NUMBER() OVER(ORDER BY RQVN.VENDOR_CD ASC) AS ROWNUM
                              FROM STOCRQVN RQVN
                             WHERE RQVN.GATE_CD = P_GATE_CD
                               AND RQVN.RFQ_NUM = P_RFQ_NUM
                               AND RQVN.RFQ_CNT = P_RFQ_CNT
                               AND RQVN.DEL_FLAG = '0'
                               AND RQVN.RFQ_PROGRESS_CD IN ('150','300')
                             GROUP BY RQVN.GATE_CD, RQVN.RFQ_NUM, RQVN.RFQ_CNT, RQVN.VENDOR_CD
                          ) A) AS CHAR(10))) + '/' + 
                   RTRIM(CAST((SELECT ifnull(MAX(B.ROWNUM), 0) FROM (
                            SELECT ROW_NUMBER() OVER(ORDER BY RQVN.VENDOR_CD ASC) AS ROWNUM
                              FROM STOCRQVN RQVN
                             WHERE RQVN.GATE_CD = P_GATE_CD
                               AND RQVN.RFQ_NUM = P_RFQ_NUM
                               AND RQVN.RFQ_CNT = P_RFQ_CNT
                               AND RQVN.DEL_FLAG = '0'
                             GROUP BY RQVN.GATE_CD, RQVN.RFQ_NUM, RQVN.RFQ_CNT, RQVN.VENDOR_CD
                          ) B) AS CHAR(10))) into returnVal ;

    RETURN returnVal;
END;

