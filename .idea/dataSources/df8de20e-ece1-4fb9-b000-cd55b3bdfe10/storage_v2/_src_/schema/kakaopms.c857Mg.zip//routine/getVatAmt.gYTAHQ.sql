create
    definer = kakaopms@`%` function getVatAmt(P_VAT_CD varchar(10), P_AMT decimal(22, 4)) returns decimal(22, 4) deterministic
BEGIN
    DECLARE returnVal NUMERIC(22,4);
    SELECT 
    case when P_VAT_CD = 'T1' then  
    P_AMT 
    /
    (select cast(CODE as unsigned) aa from stoccodd where CODE_TYPE ='P113' and DEL_FLAG = '0' and USE_FLAG = '1')
    else 0 end
    
    INTO returnVal
    ;
    RETURN returnVal;
END;

