create
    definer = kakaopms@`%` function getGmtDate(P_DATE datetime, P_USER_GMT_CD varchar(100),
                                               P_SYSTEM_GMT_CD varchar(100),
                                               P_DATE_FORMAT varchar(100)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal  VARCHAR(500);
    select CASE WHEN P_DATE IS NULL OR P_DATE is null THEN NULL
                WHEN P_DATE_FORMAT = 'yyyy/MM/dd' THEN 
                     getToChar(K.ADATE,'yyyy/MM/dd')
                WHEN P_DATE_FORMAT = 'yyyy-MM-dd' THEN 
                     getToChar(K.ADATE,'yyyy-MM-dd')
                WHEN P_DATE_FORMAT = 'dd/MM/yyyy' THEN 
                     getToChar(K.ADATE,'dd/MM/yyyy')
                WHEN P_DATE_FORMAT = 'dd-MM-yyyy' THEN 
                     getToChar(K.ADATE,'dd-MM-yyyy')
                WHEN P_DATE_FORMAT = 'dd-MM-yy' THEN 
                     getToChar(K.ADATE,'dd-MM-yy')
                WHEN P_DATE_FORMAT = 'yyyyMMdd' THEN 
                     getToChar(K.ADATE,'yyyyMMdd')
                WHEN P_DATE_FORMAT = 'ddMMyyyy' THEN 
                     getToChar(K.ADATE,'ddMMyyyy')
                WHEN P_DATE_FORMAT = 'hh:mm:ss' THEN 
                     getToChar(K.ADATE,'hh:mm:ss')
                WHEN P_DATE_FORMAT = 'hh:mm' THEN 
                     getToChar(K.ADATE,'hh:mm')
                WHEN P_DATE_FORMAT = 'hh' THEN 
                     getToChar(K.ADATE,'hh')
                WHEN P_DATE_FORMAT = 'mm' THEN 
                     getToChar(K.ADATE,'mm')
                WHEN P_DATE_FORMAT = 'dd/MM/yyyy hh:mm' THEN 
                     getToChar(K.ADATE,'dd/MM/yyyy hh:mm')
                WHEN P_DATE_FORMAT = 'yyyy/MM/dd hh:mm' THEN 
                     getToChar(K.ADATE,'yyyy/MM/dd hh:mm')
                WHEN P_DATE_FORMAT = 'yyyy-MM-dd hh:mm' THEN 
                     getToChar(K.ADATE,'yyyy-MM-dd hh:mm')
                WHEN P_DATE_FORMAT = 'yyyy/MM/dd hh:mm:ss' THEN 
                     getToChar(K.ADATE,'yyyy/MM/dd hh:mm:ss')
                WHEN P_DATE_FORMAT = 'yyyy-MM-dd hh:mm:ss' THEN
                     getToChar(K.ADATE,'yyyy-MM-dd hh:mm:ss')
                ELSE
                     getToChar(K.ADATE,'yyyyMMdd')
                end into returnVal  
      FROM (
      SELECT DATE_ADD(
            DATE_ADD(P_DATE,INTERVAL -
            CASE 
            WHEN substring(P_USER_GMT_CD, 4, 1) = '+' THEN -(substring(P_USER_GMT_CD, 5, 2)  * 60 * 60) - substring(P_USER_GMT_CD, 8, 2)  *60
            WHEN substring(P_USER_GMT_CD, 4, 1) = '-' THEN (substring(P_USER_GMT_CD, 5, 2)  * 60 * 60) + substring(P_USER_GMT_CD, 8, 2)  *60
            ELSE NULL
            end SECOND)   
         , INTERVAL
         CASE 
            WHEN substring(P_SYSTEM_GMT_CD, 4, 1) = '+' THEN -(substring(P_SYSTEM_GMT_CD, 5, 2) * 60 * 60) - substring(P_SYSTEM_GMT_CD, 8, 2) *60
            WHEN substring(P_SYSTEM_GMT_CD, 4, 1) = '-' THEN (substring(P_SYSTEM_GMT_CD, 5, 2)  * 60 * 60) + substring(P_SYSTEM_GMT_CD, 8, 2)  *60
            ELSE NULL
         end SECOND
         ) ADATE
     ) K;
    RETURN returnVal;
END;

