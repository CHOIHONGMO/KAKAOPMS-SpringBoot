create
    definer = kakaopms@`%` function getUserDeptName(P_GATE_CD varchar(10), P_USER_ID varchar(20),
                                                    P_LANG_CD varchar(10)) returns varchar(500) deterministic
begin
    
    DECLARE returnVal varchar(500);

    SELECT getDeptName(GATE_CD,COMPANY_CD,DEPT_CD,P_LANG_CD) INTO returnVal
      FROM (
          SELECT GATE_CD,COMPANY_CD,DEPT_CD
            FROM STOCUSER
           WHERE STOCUSER.GATE_CD = P_GATE_CD
             AND STOCUSER.USER_ID = P_USER_ID
          
          UNION
          
          SELECT GATE_CD,COMPANY_CD,DEPT_CD
            FROM STOCCVUR
           WHERE STOCCVUR.GATE_CD = P_GATE_CD
             AND STOCCVUR.USER_ID = P_USER_ID
    ) A limit 1;
    
    RETURN returnVal;
end;

