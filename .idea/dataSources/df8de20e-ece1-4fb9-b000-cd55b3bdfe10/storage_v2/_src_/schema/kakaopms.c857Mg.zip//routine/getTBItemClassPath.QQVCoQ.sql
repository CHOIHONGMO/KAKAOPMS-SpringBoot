create
    definer = kakaopms@`%` function getTBItemClassPath(P_GATE_CD varchar(100), P_BUYER_CD varchar(100),
                                                       P_ITEM_CD varchar(100),
                                                       P_ITEM_TYPE varchar(100)) returns varchar(500) deterministic
BEGIN
 
        DECLARE itemCls  VARCHAR(500);
        
    select 
       case when P_ITEM_TYPE = 'T' then (
                SELECT distinct concat(MTC1.ITEM_CLS_NM
                               ,CASE WHEN MTC2.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ' , MTC2.ITEM_CLS_NM)
                                     ELSE '' END
                               ,CASE WHEN MTC3.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ' , MTC3.ITEM_CLS_NM)
                                     ELSE '' END
                               ,CASE WHEN MTC4.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ' , MTC4.ITEM_CLS_NM)
                                     ELSE '' end) 
              FROM STOCMTCA MTCA 
              JOIN STOCMTGC MTGC 
               ON (MTCA.GATE_CD = MTGC.GATE_CD
               AND MTCA.BUYER_CD = MTGC.BUYER_CD
               AND MTCA.ITEM_CLS1 = MTGC.ITEM_CLS1
               AND MTCA.ITEM_CLS2 = (CASE WHEN (MTGC.ITEM_CLS2 IS NULL OR MTGC.ITEM_CLS2 = '') THEN '*' ELSE MTGC.ITEM_CLS2 END)
               AND MTCA.ITEM_CLS3 = (CASE WHEN (MTGC.ITEM_CLS3 IS NULL OR MTGC.ITEM_CLS3 = '') THEN '*' ELSE MTGC.ITEM_CLS3 END)
               AND MTCA.ITEM_CLS4 = (CASE WHEN (MTGC.ITEM_CLS4 IS NULL OR MTGC.ITEM_CLS4 = '') THEN '*' ELSE MTGC.ITEM_CLS4 END)
               AND MTGC.DEL_FLAG = '0')
              LEFT OUTER JOIN STOCMTCA MTC1
               ON (MTCA.GATE_CD = MTC1.GATE_CD
               AND MTCA.BUYER_CD = MTC1.BUYER_CD
               AND MTCA.ITEM_CLS1 = MTC1.ITEM_CLS1
               AND MTC1.ITEM_CLS_TYPE = 'C1'
               AND MTC1.DEL_FLAG = '0')
              LEFT OUTER JOIN STOCMTCA MTC2
               ON (MTCA.GATE_CD = MTC2.GATE_CD
               AND MTCA.BUYER_CD = MTC2.BUYER_CD
               AND MTCA.ITEM_CLS1 = MTC2.ITEM_CLS1
               AND MTCA.ITEM_CLS2 = MTC2.ITEM_CLS2
               AND MTC2.ITEM_CLS_TYPE = 'C2'
               AND MTC2.DEL_FLAG = '0')
              LEFT OUTER JOIN STOCMTCA MTC3
               ON (MTCA.GATE_CD = MTC3.GATE_CD
               AND MTCA.BUYER_CD = MTC3.BUYER_CD
               AND MTCA.ITEM_CLS1 = MTC3.ITEM_CLS1
               AND MTCA.ITEM_CLS2 = MTC3.ITEM_CLS2
               AND MTCA.ITEM_CLS3 = MTC3.ITEM_CLS3
               AND MTC3.ITEM_CLS_TYPE = 'C3'
               AND MTC3.DEL_FLAG = '0')
              LEFT OUTER JOIN STOCMTCA MTC4
               ON (MTCA.GATE_CD = MTC4.GATE_CD
               AND MTCA.BUYER_CD = MTC4.BUYER_CD
               AND MTCA.ITEM_CLS1 = MTC4.ITEM_CLS1
               AND MTCA.ITEM_CLS2 = MTC4.ITEM_CLS2
               AND MTCA.ITEM_CLS3 = MTC4.ITEM_CLS3
               AND MTCA.ITEM_CLS4 = (CASE WHEN (MTGC.ITEM_CLS4 IS NULL OR MTGC.ITEM_CLS4 = '') THEN '*' ELSE MTGC.ITEM_CLS4 END)
               AND MTC4.ITEM_CLS_TYPE = 'C4'
               AND MTC4.DEL_FLAG = '0')
             WHERE MTCA.GATE_CD = P_GATE_CD
               AND MTCA.BUYER_CD = P_BUYER_CD
               AND MTCA.USE_FLAG = '1'
               AND MTCA.DEL_FLAG = '0'
               AND MTGC.ITEM_CD = P_ITEM_CD
               AND MTGC.M_CATE_FLAG = '0'  )
        
        when  P_ITEM_TYPE = 'B' then 
        
          (SELECT distinct concat( MTC1.ITEM_CLS_NM
                           ,CASE WHEN MTC2.ITEM_CLS_NM IS NOT NULL then CONCAT( ' > ' , MTC2.ITEM_CLS_NM)
                                 ELSE '' END
                           ,CASE WHEN MTC3.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ' , MTC3.ITEM_CLS_NM)
                                 ELSE '' END
                           ,CASE WHEN MTC4.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ' , MTC4.ITEM_CLS_NM)
                                 ELSE '' end) 
          FROM STOCMTCA MTCA 
          JOIN STOCMTGC MTGC 
           ON (MTCA.GATE_CD = MTGC.GATE_CD
           AND MTCA.BUYER_CD = MTGC.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTGC.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = (CASE WHEN (MTGC.ITEM_CLS2 IS NULL OR MTGC.ITEM_CLS2 = '') THEN '*' ELSE MTGC.ITEM_CLS2 END)
           AND MTCA.ITEM_CLS3 = (CASE WHEN (MTGC.ITEM_CLS3 IS NULL OR MTGC.ITEM_CLS3 = '') THEN '*' ELSE MTGC.ITEM_CLS3 END)
           AND MTCA.ITEM_CLS4 = (CASE WHEN (MTGC.ITEM_CLS4 IS NULL OR MTGC.ITEM_CLS4 = '') THEN '*' ELSE MTGC.ITEM_CLS4 END)
           AND MTGC.DEL_FLAG = '0')
          LEFT OUTER JOIN STOCMTCA MTC1
           ON (MTCA.GATE_CD = MTC1.GATE_CD
           AND MTCA.BUYER_CD = MTC1.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC1.ITEM_CLS1
           AND MTC1.ITEM_CLS_TYPE = 'C1'
           AND MTC1.DEL_FLAG = '0')
          LEFT OUTER JOIN STOCMTCA MTC2
           ON (MTCA.GATE_CD = MTC2.GATE_CD
           AND MTCA.BUYER_CD = MTC2.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC2.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC2.ITEM_CLS2
           AND MTC2.ITEM_CLS_TYPE = 'C2'
           AND MTC2.DEL_FLAG = '0')
          LEFT OUTER JOIN STOCMTCA MTC3
           ON (MTCA.GATE_CD = MTC3.GATE_CD
           AND MTCA.BUYER_CD = MTC3.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC3.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC3.ITEM_CLS2
           AND MTCA.ITEM_CLS3 = MTC3.ITEM_CLS3
           AND MTC3.ITEM_CLS_TYPE = 'C3'
           AND MTC3.DEL_FLAG = '0')
          LEFT OUTER JOIN STOCMTCA MTC4
           ON (MTCA.GATE_CD = MTC4.GATE_CD
           AND MTCA.BUYER_CD = MTC4.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC4.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC4.ITEM_CLS2
           AND MTCA.ITEM_CLS3 = MTC4.ITEM_CLS3
           AND MTCA.ITEM_CLS4 = (CASE WHEN (MTGC.ITEM_CLS4 IS NULL OR MTGC.ITEM_CLS4 = '') THEN '*' ELSE MTGC.ITEM_CLS4 END)
           AND MTC4.ITEM_CLS_TYPE = 'C4'
           AND MTC4.DEL_FLAG = '0')
         WHERE MTCA.GATE_CD = P_GATE_CD
           AND MTCA.BUYER_CD = P_BUYER_CD
           AND MTCA.USE_FLAG = '1'
           AND MTCA.DEL_FLAG = '0'
           AND MTGC.BUYER_ITEM_CD = P_ITEM_CD
           AND MTGC.M_CATE_FLAG = '0')
         end into itemCls;
          

     RETURN itemCls;

END;

