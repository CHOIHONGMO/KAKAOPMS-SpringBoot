create
    definer = kakaopms@`%` function getBankNm(P_GATE_CD varchar(10), P_LANG_CD varchar(20),
                                              P_BANK_CD varchar(20)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);
    
    SELECT MAX(CODE_DESC)   INTO returnVal
     FROM STOCCODD
    WHERE GATE_CD  = P_GATE_CD
      AND LANG_CD  = P_LANG_CD
      AND CODE_TYPE= 'M017'
      AND CODE     = P_BANK_CD
      AND DEL_FLAG = '0';
       
    RETURN returnVal;
END;

