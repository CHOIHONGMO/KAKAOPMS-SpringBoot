create
    definer = kakaopms@`%` function fn_trunc(input varchar(500)) returns varchar(500) deterministic
BEGIN
    DECLARE value varchar(500);
    
    SELECT CAST(ROUND(input,1) AS DECIMAL(10)) INTO value;
    
    RETURN value;
END;

