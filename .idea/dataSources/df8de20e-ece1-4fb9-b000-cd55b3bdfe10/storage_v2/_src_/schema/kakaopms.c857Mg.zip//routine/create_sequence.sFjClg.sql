create
    definer = kakaopms@`%` procedure create_sequence(IN the_name text) modifies sql data
begin
    delete from sequences where name = the_name;
    insert into sequences values (the_name,0);
END;

