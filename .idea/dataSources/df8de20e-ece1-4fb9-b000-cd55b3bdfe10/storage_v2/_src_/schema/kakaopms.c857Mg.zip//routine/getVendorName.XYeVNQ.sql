create
    definer = kakaopms@`%` function getVendorName(P_GATE_CD varchar(10), P_VENDOR_CD varchar(10),
                                                  P_LANG_CODE varchar(10)) returns varchar(500) deterministic
begin
    DECLARE returnVal varchar(500);
    
    SELECT CASE P_LANG_CODE
                WHEN 'EN' THEN IFNULL(VENDOR_NM, VENDOR_NM)
                ELSE VENDOR_NM
            END INTO returnVal
      FROM STOCVNGL
     WHERE GATE_CD   = P_GATE_CD
       AND VENDOR_CD = P_VENDOR_CD;
    
    RETURN returnVal;
END;

