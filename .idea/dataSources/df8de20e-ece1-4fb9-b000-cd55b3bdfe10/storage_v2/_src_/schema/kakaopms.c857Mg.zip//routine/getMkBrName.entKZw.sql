create
    definer = kakaopms@`%` function getMkBrName(gateCd varchar(10), buyerCd varchar(10), mkbrType varchar(30),
                                                mkbrCd varchar(30)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);

    SELECT MKBR_NM INTO returnVal
      FROM STOCMKBR
     WHERE GATE_CD   = gateCd
       and BUYER_CD  = buyerCd
       AND MKBR_TYPE = mkbrType
       AND MKBR_CD   = mkbrCd;

    RETURN returnVal;
END;

