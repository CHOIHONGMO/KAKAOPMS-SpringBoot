create
    definer = kakaopms@`%` function getMultiDesc(P_GATE_CD varchar(10), P_MULTI_CD varchar(20), P_LANG_CD varchar(20),
                                                 P_COLUMN_ID varchar(30),
                                                 P_SCREEN_ID varchar(30)) returns varchar(2000) deterministic
BEGIN
    DECLARE returnVal varchar(2000);
    
    SELECT CASE WHEN P_MULTI_CD = 'SA' THEN 
                CASE WHEN LENGTH((SELECT max(STOCMULG.MULTI_DESC)
                                    FROM STOCMULG
                                   WHERE 
                                       STOCMULG.GATE_CD = P_GATE_CD AND 
                                       STOCMULG.DEL_FLAG = '0' AND 
                                       STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                       STOCMULG.LANG_CD = P_LANG_CD AND 
                                       STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                       STOCMULG.ACTION_CD = P_COLUMN_ID)) = 0  THEN (
                                                                  SELECT max(STOCMULG.MULTI_DESC)
                                                                  FROM STOCMULG
                                                                  WHERE 
                                                                     STOCMULG.GATE_CD = P_GATE_CD AND 
                                                                     STOCMULG.DEL_FLAG = '0' AND 
                                                                     STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                                     STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                                                     STOCMULG.ACTION_CD = P_COLUMN_ID
                                                                  GROUP BY STOCMULG.GATE_CD
                                                               )
                                                            ELSE 
                                                            (SELECT max(STOCMULG.MULTI_DESC)
                                                                FROM STOCMULG
                                                                WHERE 
                                                                   STOCMULG.GATE_CD = P_GATE_CD AND 
                                                                   STOCMULG.DEL_FLAG = '0' AND 
                                                                   STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                                   STOCMULG.LANG_CD = P_LANG_CD AND 
                                                                   STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                                                   STOCMULG.ACTION_CD = P_COLUMN_ID)
                END 
            WHEN P_MULTI_CD = 'MT' THEN 
                    CASE WHEN LENGTH((SELECT max(STOCMULG.MULTI_DESC)
                                   FROM STOCMULG
                                   WHERE 
                                      STOCMULG.GATE_CD = P_GATE_CD AND 
                                      STOCMULG.DEL_FLAG = '0' AND 
                                      STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                      STOCMULG.LANG_CD = P_LANG_CD AND 
                                      STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                      STOCMULG.TMPL_MENU_CD = P_COLUMN_ID)) = 0 THEN (
                                                                     SELECT  max(STOCMULG.MULTI_DESC)
                                                                     FROM STOCMULG
                                                                     WHERE 
                                                                        STOCMULG.GATE_CD = P_GATE_CD AND 
                                                                        STOCMULG.DEL_FLAG = '0' AND 
                                                                        STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                                        STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                                                        STOCMULG.TMPL_MENU_CD = P_COLUMN_ID
                                                                     GROUP BY STOCMULG.GATE_CD
                                      )
                                      ELSE (
                                                                SELECT max(STOCMULG.MULTI_DESC)
                                                               FROM STOCMULG
                                                               WHERE 
                                                                  STOCMULG.GATE_CD = P_GATE_CD AND 
                                                                  STOCMULG.DEL_FLAG = '0' AND 
                                                                  STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                                  STOCMULG.LANG_CD = P_LANG_CD AND 
                                                                  STOCMULG.SCREEN_ID = P_SCREEN_ID AND 
                                                                  STOCMULG.TMPL_MENU_CD = P_COLUMN_ID
                                      )  END
            WHEN P_MULTI_CD = 'SC' THEN
                    CASE WHEN LENGTH((
                                      SELECT max(STOCMULG.MULTI_DESC)
                                      FROM STOCMULG
                                      WHERE 
                                         STOCMULG.GATE_CD = P_GATE_CD AND 
                                         STOCMULG.DEL_FLAG = '0' AND 
                                         STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                         STOCMULG.LANG_CD = P_LANG_CD AND 
                                         (STOCMULG.SCREEN_ID = P_COLUMN_ID OR STOCMULG.SCREEN_ID = P_SCREEN_ID)  )) = 0 THEN (
                                                                                                                                SELECT max(STOCMULG.MULTI_DESC)
                                                                                                                                FROM STOCMULG
                                                                                                                                WHERE 
                                                                                                                                   STOCMULG.GATE_CD = P_GATE_CD AND 
                                                                                                                                   STOCMULG.DEL_FLAG = '0' AND 
                                                                                                                                   STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                                                                                                   (STOCMULG.SCREEN_ID = P_COLUMN_ID OR STOCMULG.SCREEN_ID = P_SCREEN_ID)
                                                                                                                                GROUP BY STOCMULG.GATE_CD
                                                                                                                            )
                                         ELSE (
                                                 SELECT max(STOCMULG.MULTI_DESC)
                                                 FROM STOCMULG
                                                 WHERE 
                                                 STOCMULG.GATE_CD = P_GATE_CD AND 
                                                 STOCMULG.DEL_FLAG = '0' AND 
                                                 STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                                 STOCMULG.LANG_CD = P_LANG_CD AND 
                                                 (STOCMULG.SCREEN_ID = P_COLUMN_ID OR STOCMULG.SCREEN_ID = P_SCREEN_ID)
                                         ) END


            ELSE CASE WHEN LENGTH((
                                  SELECT max(STOCMULG.MULTI_DESC)
                                  FROM STOCMULG
                                  WHERE 
                                     STOCMULG.GATE_CD = P_GATE_CD AND 
                                     STOCMULG.DEL_FLAG = '0' AND 
                                     STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                     STOCMULG.LANG_CD = P_LANG_CD AND 
                     
                                     CASE P_MULTI_CD
                                        WHEN 'AU' THEN STOCMULG.AUTH_CD
                                        WHEN 'MG' THEN STOCMULG.MENU_GROUP_CD
                                        WHEN 'TG' THEN STOCMULG.TMPL_MENU_GROUP_CD
                                        WHEN 'AP' THEN STOCMULG.ACTION_PROFILE_CD
                                     END = P_COLUMN_ID
                            )) = 0 THEN (
                                        SELECT max(STOCMULG.MULTI_DESC)
                                        FROM STOCMULG
                                        WHERE 
                                           STOCMULG.GATE_CD = P_GATE_CD AND 
                                           STOCMULG.DEL_FLAG = '0' AND 
                                           STOCMULG.MULTI_CD = P_MULTI_CD AND 
                           
                                           CASE P_MULTI_CD
                                              WHEN 'AU' THEN STOCMULG.AUTH_CD
                                              WHEN 'MG' THEN STOCMULG.MENU_GROUP_CD
                                              WHEN 'TG' THEN STOCMULG.TMPL_MENU_GROUP_CD
                                              WHEN 'AP' THEN STOCMULG.ACTION_PROFILE_CD
                                           END = P_COLUMN_ID
                                        GROUP BY STOCMULG.GATE_CD
                                        )
                            else (
                                  SELECT max(STOCMULG.MULTI_DESC)
                                  FROM STOCMULG
                                  WHERE 
                                     STOCMULG.GATE_CD = P_GATE_CD AND 
                                     STOCMULG.DEL_FLAG = '0' AND 
                                     STOCMULG.MULTI_CD = P_MULTI_CD AND 
                                     STOCMULG.LANG_CD = P_LANG_CD AND 
                     
                                     CASE P_MULTI_CD
                                        WHEN 'AU' THEN STOCMULG.AUTH_CD
                                        WHEN 'MG' THEN STOCMULG.MENU_GROUP_CD
                                        WHEN 'TG' THEN STOCMULG.TMPL_MENU_GROUP_CD
                                        WHEN 'AP' THEN STOCMULG.ACTION_PROFILE_CD
                                     END = P_COLUMN_ID
                            )
            END
        END INTO returnVal;
    
    RETURN returnVal;
END;

