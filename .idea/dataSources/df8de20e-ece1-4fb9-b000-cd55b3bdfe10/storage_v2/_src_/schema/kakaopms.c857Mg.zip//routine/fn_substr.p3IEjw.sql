create
    definer = kakaopms@`%` function fn_substr(P_TEXT varchar(4000), P_A decimal, P_B decimal) returns varchar(4000) deterministic
BEGIN

    DECLARE returnVal varchar(500);

    select SUBSTRING(P_TEXT,P_A,P_B) into returnVal;

    RETURN returnVal;

END;

