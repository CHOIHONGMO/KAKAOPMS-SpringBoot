create
    definer = kakaopms@`%` function getCublInfo(P_GATE_CD varchar(10), P_CUST_CD varchar(20), P_CUBL_SEQ decimal(6),
                                                P_INFO_TYPE varchar(20)) returns varchar(2000) deterministic
BEGIN

    DECLARE value varchar(2000);
    
    SELECT
        CASE P_INFO_TYPE
            WHEN 'ACC_CD' THEN ACC_CD
            WHEN 'CUBL_NM' THEN CUBL_NM
            WHEN 'CUBL_ZIP_CD' THEN CUBL_ZIP_CD
            WHEN 'CUBL_ADDR1' THEN CUBL_ADDR1
            WHEN 'CUBL_ADDR2' THEN CUBL_ADDR2
            WHEN 'CUBL_COMPANY_NM' THEN COMPANY_NM
            WHEN 'CUBL_IRS_NUM' THEN IRS_NUM
            WHEN 'CUBL_CEO_USER_NM' THEN CEO_USER_NM
            WHEN 'CUBL_BUSINESS_TYPE' THEN BUSINESS_TYPE
            WHEN 'CUBL_INDUSTRY_TYPE' THEN INDUSTRY_TYPE
            WHEN 'CUBL_IRS_SUB_NUM' THEN IRS_SUB_NUM
            WHEN 'CUBL_IRS_SUB_ADDR' THEN IRS_SUB_ADDR
            WHEN 'CUBL_BANK_NM' THEN CUBL_BANK_NM
            WHEN 'CUBL_ACCOUNT_NUM' THEN CUBL_ACCOUNT_NUM
            WHEN 'CUBL_ACCOUNT_NM' THEN CUBL_ACCOUNT_NM
            WHEN 'CUBL_USER_NM' THEN CUBL_USER_NM
            WHEN 'CUBL_USER_TEL_NUM' THEN CUBL_USER_TEL_NUM
            WHEN 'CUBL_USER_FAX_NUM' THEN CUBL_USER_FAX_NUM
            WHEN 'CUBL_USER_CELL_NUM' THEN CUBL_USER_CELL_NUM
            WHEN 'CUBL_USER_EMAIL' THEN CUBL_USER_EMAIL
            WHEN 'CUBL_IRS_SUB_ZIP_CD' THEN IRS_SUB_ZIP_CD
            WHEN 'CUBL_MNG_ID' THEN MNG_ID
            ELSE ''
        END INTO value
      FROM STOCCUBL
     WHERE GATE_CD = P_GATE_CD
       AND CUST_CD = P_CUST_CD
       AND CUBL_SQ = P_CUBL_SEQ;
    
    RETURN value;
END;

