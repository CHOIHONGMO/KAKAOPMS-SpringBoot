create
    definer = kakaopms@`%` function setGmtDate(P_DATE varchar(100), P_USER_GMT_CD varchar(100),
                                               P_SYSTEM_GMT_CD varchar(100),
                                               P_DATE_FORMAT varchar(100)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal  VARCHAR(500);

    SELECT 
           CASE WHEN P_DATE IS NULL OR P_DATE = '' THEN NULL
           ELSE
               CONVERT(P_DATE, DATETIME) -
               (CASE
                       WHEN substring(P_USER_GMT_CD,4,1) = '+'
                       THEN (substring(P_USER_GMT_CD,5,2)/24) + substring(P_USER_GMT_CD,8,2)/(24*60)
                       WHEN substring(P_USER_GMT_CD,4,1) = '-'
                       THEN -(substring(P_USER_GMT_CD,5,2)/24) - substring(P_USER_GMT_CD,8,2)/(24*60)
                       ELSE null
                END)
               +
               (CASE
                       WHEN substring(P_SYSTEM_GMT_CD,4,1) = '+'
                       THEN (substring(P_SYSTEM_GMT_CD,5,2)/24) + substring(P_SYSTEM_GMT_CD,8,2)/(24*60)
                       WHEN substring(P_SYSTEM_GMT_CD,4,1) = '-'
                       THEN -(substring(P_SYSTEM_GMT_CD,5,2)/24) - substring(P_SYSTEM_GMT_CD,8,2)/(24*60)
                       ELSE null
                END)
           END into returnVal;
 
    RETURN returnVal;
END;

