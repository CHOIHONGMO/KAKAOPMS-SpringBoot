create
    definer = kakaopms@`%` function getPlantName(gateCd varchar(10), buyerCd varchar(10), plantCd varchar(30)) returns varchar(200) deterministic
BEGIN
    DECLARE returnVal  varchar(200);

    SELECT PLANT_NM into returnVal
      FROM STOCOGPL
     WHERE GATE_CD  = gateCd
       AND BUYER_CD = buyerCd
       AND PLANT_CD = plantCd;
      
    RETURN returnVal;
END;

