create
    definer = kakaopms@`%` function getRegionInfoByCust(P_GATE_CD varchar(100), P_CUST_CD varchar(100),
                                                        P_INFO_TYPE varchar(10),
                                                        P_LANG_CD varchar(10)) returns varchar(500) deterministic
BEGIN
     
    DECLARE value varchar(500);
    
    SELECT INSERT((SELECT ', '+( CASE WHEN P_INFO_TYPE = 'CD' THEN CURG.REGION_CD
                                      WHEN P_INFO_TYPE = 'NM' THEN getCodeName(CURG.GATE_CD, 'MP005', CURG.REGION_CD, P_LANG_CD)
                                      ELSE CURG.REGION_CD
                                 END)
                    FROM STOCCURG CURG
                   WHERE CURG.GATE_CD = P_GATE_CD
                     AND CURG.CUST_CD = P_CUST_CD
                     AND CURG.DEL_FLAG = '0'
                  ), 1, 2, '') INTO value;

    RETURN value;
END;

