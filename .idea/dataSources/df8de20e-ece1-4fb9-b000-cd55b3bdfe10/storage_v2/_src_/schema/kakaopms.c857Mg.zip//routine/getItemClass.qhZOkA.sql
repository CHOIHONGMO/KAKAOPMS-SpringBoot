create
    definer = kakaopms@`%` function getItemClass(P_GATE_CD varchar(100), P_BUYER_CD varchar(100),
                                                 P_ITEM_CLS_CD varchar(100),
                                                 P_CLS_NO varchar(100)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);
/*
    SELECT
        A.ITEM_CLS_NM INTO returnVal
      FROM (
      */
        SELECT ITEM_CLS_NM INTO returnVal
          FROM STOCMTCA
         WHERE GATE_CD  = P_GATE_CD
           AND BUYER_CD = P_BUYER_CD
           AND DEL_FLAG = '0'
           AND USE_FLAG = '1'
           AND (CASE WHEN P_CLS_NO = '1' THEN ITEM_CLS1 WHEN P_CLS_NO = '2' THEN ITEM_CLS2 WHEN P_CLS_NO = '3' THEN ITEM_CLS3 WHEN P_CLS_NO = '4' THEN ITEM_CLS4 END) = P_ITEM_CLS_CD
           AND (CASE WHEN P_CLS_NO = '1' THEN 'C1' WHEN P_CLS_NO = '2' THEN 'C2' WHEN P_CLS_NO = '3' THEN 'C3' WHEN P_CLS_NO = '4' THEN 'C4' END) = ITEM_CLS_TYPE
        LIMIT 1;
/*
         ORDER BY BUYER_CD ASC, ITEM_CLS1 ASC, ITEM_CLS2 ASC, ITEM_CLS3 ASC, ITEM_CLS4 ASC
      ) A 
*/
    RETURN returnVal;
end;

