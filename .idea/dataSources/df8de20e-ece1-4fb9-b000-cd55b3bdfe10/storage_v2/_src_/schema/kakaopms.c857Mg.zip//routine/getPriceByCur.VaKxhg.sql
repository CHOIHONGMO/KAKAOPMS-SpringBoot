create
    definer = kakaopms@`%` function getPriceByCur(P_CUR_CODE varchar(100), P_PRICE decimal(22, 5)) returns decimal(22, 4) deterministic
BEGIN
    DECLARE value   DECIMAL(22,4);
    
    SELECT CASE WHEN P_CUR_CODE = 'KRW' THEN CAST(P_PRICE AS DECIMAL(22,0))
                WHEN P_CUR_CODE = 'USD' THEN CAST(P_PRICE AS DECIMAL(22,4))
                WHEN P_CUR_CODE = 'VND' THEN CAST(P_PRICE AS DECIMAL(22,0))
                ELSE CAST(P_PRICE AS DECIMAL(22,0)) END INTO value;
    
    RETURN value;
END;

