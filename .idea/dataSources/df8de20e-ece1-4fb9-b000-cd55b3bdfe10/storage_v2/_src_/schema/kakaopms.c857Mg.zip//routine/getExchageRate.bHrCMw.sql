create
    definer = kakaopms@`%` function getExchageRate(P_YYMMDD varchar(8), P_CUR varchar(10), P_NUMBER decimal(16, 3),
                                                   P_TYPE varchar(10)) returns decimal(22, 3) deterministic
BEGIN
    DECLARE returnVal NUMERIC(22,3) DEFAULT 0;
    SELECT 
    case when P_TYPE = 'exchage' then P_NUMBER * TT_SLL_RT 
    else TT_SLL_RT end 
    INTO returnVal
    FROM STOCEXCH A
    where A.PBLD_DT = P_YYMMDD
    and A.SQN = ( 
        select MAX(SQN) from STOCEXCH 
        where PBLD_DT = P_YYMMDD
        and EXHG_RT_CUR_CD = P_CUR
    )
    and A.EXHG_RT_CUR_CD = P_CUR;
    RETURN ifnull(returnVal, 0);
end;

