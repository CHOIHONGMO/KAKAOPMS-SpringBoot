create
    definer = kakaopms@`%` function getGrQtyAmt(P_BUYER_CD varchar(10), P_PO_NUM varchar(20), P_PO_SQ decimal,
                                                P_TYPE varchar(20)) returns decimal(22, 4) deterministic
BEGIN
    DECLARE returnVal NUMERIC(22,4);

    SELECT IFNULL(SUM(CASE WHEN P_TYPE = 'QT' THEN
                             CASE WHEN 'A' IN ('A','B') THEN DT.GR_QT ELSE 0 END
                        ELSE DT.GR_AMT
                    END
                ), 0) INTO returnVal
      FROM STOPGRDT DT
      JOIN STOPGRHD HD
           ON (HD.GATE_CD  = HD.GATE_CD
           and HD.BUYER_CD = DT.BUYER_CD
           AND HD.GR_NUM   = DT.GR_NUM
           AND DT.DEL_FLAG = '0')
     WHERE DT.GATE_CD = '100'
       AND DT.BUYER_CD      = P_BUYER_CD
       AND DT.PO_NUM      = P_PO_NUM
       AND DT.PO_SQ       = P_PO_SQ
       and HD.GATE_CD     = '100'
       AND HD.SIGN_STATUS = 'E'
       AND HD.DEL_FLAG    = '0'      
       ;

    RETURN returnVal;
END;

