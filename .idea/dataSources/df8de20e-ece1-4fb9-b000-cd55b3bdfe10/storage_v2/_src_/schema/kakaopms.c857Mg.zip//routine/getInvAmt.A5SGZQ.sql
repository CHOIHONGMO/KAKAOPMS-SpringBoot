create
    definer = kakaopms@`%` function getInvAmt(P_PO_NUM varchar(20), P_PO_SQ decimal) returns decimal(22, 5) deterministic
BEGIN

    DECLARE returnVal NUMERIC(22,5);

     SELECT SUM(IFNULL(DT.INV_AMT,0)) INTO returnVal
      FROM STOPIVHD HD
      JOIN STOPIVDT DT
           ON (DT.GATE_CD  = HD.GATE_CD
           AND DT.INV_NUM  = HD.INV_NUM
           AND DT.DEL_FLAG = '0')
     WHERE HD.GATE_CD     = '100'
       AND HD.PROGRESS_CD IN ('6100','6120','7100','7120')
       AND HD.DEL_FLAG    = '0'
       AND DT.PO_NUM      = P_PO_NUM
       AND DT.PO_SQ       = P_PO_SQ;

    RETURN returnVal;
END;

