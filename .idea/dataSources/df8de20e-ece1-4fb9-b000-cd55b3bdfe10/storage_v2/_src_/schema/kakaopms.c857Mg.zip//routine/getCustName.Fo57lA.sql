create
    definer = kakaopms@`%` function getCustName(P_GATE_CD varchar(10), P_CUST_CD varchar(20)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);
    
    SELECT CUST_NM INTO returnVal
      FROM STOCCUST
     WHERE GATE_CD = P_GATE_CD
       AND CUST_CD = P_CUST_CD;
       
     RETURN returnVal;
END;

