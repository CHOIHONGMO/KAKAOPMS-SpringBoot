create
    definer = kakaopms@`%` function getComCode(P_GATE_CD varchar(100), P_CODE_TYPE varchar(100), P_CODE varchar(100),
                                               P_TEXT_NO decimal,
                                               P_LANG_CODE varchar(100)) returns varchar(100) deterministic
BEGIN
    DECLARE returnVal varchar(100);

    SELECT A.CODE_TEXT INTO returnVal
      FROM (
        SELECT
            (CASE P_TEXT_NO
                 WHEN 0 THEN CODE_DESC
                 WHEN 1 THEN TEXT1
                 WHEN 2 THEN TEXT2
                 WHEN 3 THEN TEXT3
                 WHEN 4 THEN TEXT4
                 ELSE CODE_DESC END) AS CODE_TEXT
         FROM STOCCODD
        WHERE GATE_CD  = P_GATE_CD
          AND CODE_TYPE= P_CODE_TYPE
          AND LANG_CD  = P_LANG_CODE
          AND CODE     = P_CODE
          AND USE_FLAG = '1'
          AND DEL_FLAG = '0'
    ) A
    LIMIT 1;
    
    RETURN returnVal;
END;

