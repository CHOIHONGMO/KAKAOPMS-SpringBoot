create
    definer = kakaopms@`%` function getParentDeptCd(gateCd varchar(3), buyerCd varchar(10), deptCd varchar(30),
                                                    deptLvl decimal(3)) returns varchar(30) deterministic
BEGIN
    DECLARE value varchar(30);

    SELECT CASE WHEN deptLvl = 1 THEN DEPT_CD
                WHEN deptLvl = 2 THEN PARENT_DEPT_CD
                WHEN deptLvl = 3 THEN GETDEPTINFO(GATE_CD, BUYER_CD,
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                WHEN deptLvl = 4 THEN GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                WHEN deptLvl = 5 THEN GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                WHEN deptLvl = 6 THEN GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                WHEN deptLvl = 7 THEN GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                WHEN deptLvl = 8 THEN GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, 
                                      GETDEPTINFO(GATE_CD, BUYER_CD, DEPT_CD, 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD'), 'PARENT_DEPT_CD')
                ELSE ''
            END INTO value
      FROM STOCOGDP
     WHERE GATE_CD  = gateCd
       AND BUYER_CD = buyerCd
       AND DEPT_CD  = deptCd
       AND DEL_FLAG = '0';

    RETURN value;
END;

