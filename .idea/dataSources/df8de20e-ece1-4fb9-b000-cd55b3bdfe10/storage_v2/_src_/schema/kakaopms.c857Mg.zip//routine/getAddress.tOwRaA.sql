create
    definer = kakaopms@`%` function getAddress(P_GATE_CD varchar(10), P_BUYER_CD varchar(20),
                                               P_LANG_CD varchar(20)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);

    SELECT
         CASE WHEN P_LANG_CD = 'EN' THEN IFNULL(ADDR_ENG, ADDR)
            ELSE ADDR
         END    INTO returnVal
     FROM STOCOGCM
    WHERE GATE_CD  = P_GATE_CD
      AND BUYER_CD = P_BUYER_CD;

    RETURN returnVal;
END;

