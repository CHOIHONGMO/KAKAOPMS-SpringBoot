create
    definer = kakaopms@`%` function getUserPlantName(P_GATE_CD varchar(10), P_USER_ID varchar(20),
                                                     P_LANG_CD varchar(10)) returns varchar(500) deterministic
BEGIN
    DECLARE buyerCd varchar(10);
    DECLARE plantCd varchar(10);
    DECLARE value   varchar(500);

    SELECT Z.COMPANY_CD, Z.PLANT_CD INTO buyerCd, plantCd
      FROM (
        SELECT COMPANY_CD, PLANT_CD AS PLANT_CD
          FROM STOCCVUR
         WHERE GATE_CD  = P_GATE_CD
           AND USER_ID  = P_USER_ID
           AND DEL_FLAG = '0'
        
        UNION         
             
        SELECT COMPANY_CD, PLANT_CD AS PLANT_CD
          FROM STOCUSER
         WHERE GATE_CD  = P_GATE_CD
           AND USER_ID  = P_USER_ID
           AND DEL_FLAG = '0'
      ) Z
    WHERE 1 = 1;
    
    SELECT MAX(Z.PLANT_NM) INTO value
      FROM (
        SELECT CASE WHEN P_LANG_CD = 'KO' THEN PLANT_NM
                    ELSE PLANT_NM_ENG
               END AS PLANT_NM
          FROM STOCOGPL
         WHERE GATE_CD  = P_GATE_CD
           AND BUYER_CD = buyerCd
           AND PLANT_CD = plantCd
           AND DEL_FLAG = '0'
        
        UNION ALL
        
        SELECT PLANT_NM
          FROM STOCCUPL
         WHERE GATE_CD  = P_GATE_CD
           AND CUST_CD  = buyerCd
           AND PLANT_CD = plantCd
           AND DEL_FLAG = '0'
      ) Z
    WHERE 1 = 1;
    
    RETURN value;
END;

