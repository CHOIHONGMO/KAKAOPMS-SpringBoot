create
    definer = kakaopms@`%` function getRfqProgressStatus(P_PROGRESS_CODE varchar(100), P_CLOSE_DATE datetime) returns varchar(50) deterministic
BEGIN
    DECLARE returnVal varchar(50);
    
    SELECT
        CASE WHEN P_CLOSE_DATE IS NULL OR P_CLOSE_DATE = '' THEN '100'
             WHEN P_PROGRESS_CODE IS NULL THEN ''
             WHEN P_CLOSE_DATE > NOW() THEN P_PROGRESS_CODE
             WHEN P_PROGRESS_CODE = '400' OR P_PROGRESS_CODE = '450' THEN P_PROGRESS_CODE
             ELSE '300'
        END INTO returnVal;
    
    RETURN returnVal;
END;

