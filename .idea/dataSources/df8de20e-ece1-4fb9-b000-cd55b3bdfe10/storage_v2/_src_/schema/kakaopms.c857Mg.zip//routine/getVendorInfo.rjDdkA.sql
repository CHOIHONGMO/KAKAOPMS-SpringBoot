create
    definer = kakaopms@`%` function getVendorInfo(P_GATE_CD varchar(100), P_VENDOR_CD varchar(100),
                                                  P_INFO_TYPE varchar(100)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal  varchar(500);
      SELECT 
         CASE 
            WHEN P_INFO_TYPE = 'VENDOR_CD' THEN STOCVNGL.VENDOR_CD
            WHEN P_INFO_TYPE = 'VENDOR_NM' THEN STOCVNGL.VENDOR_NM
            WHEN P_INFO_TYPE = 'IRS_NO' THEN STOCVNGL.IRS_NO
            WHEN P_INFO_TYPE = 'CEO_USER_NM' THEN STOCVNGL.CEO_USER_NM
            WHEN P_INFO_TYPE = 'HQ_ADDR_1' THEN STOCVNGL.HQ_ADDR_1
            WHEN P_INFO_TYPE = 'HQ_ADDR_2' THEN STOCVNGL.HQ_ADDR_2
            WHEN P_INFO_TYPE = 'BUSINESS_TYPE' THEN STOCVNGL.BUSINESS_TYPE
            WHEN P_INFO_TYPE = 'INDUSTRY_TYPE' THEN STOCVNGL.INDUSTRY_TYPE
            ELSE NULL
         end into returnVal
      FROM STOCVNGL
      WHERE 
         GATE_CD   = P_GATE_CD AND 
         VENDOR_CD = P_VENDOR_CD AND 
         DEL_FLAG  = '0';
     RETURN returnVal;
END;

