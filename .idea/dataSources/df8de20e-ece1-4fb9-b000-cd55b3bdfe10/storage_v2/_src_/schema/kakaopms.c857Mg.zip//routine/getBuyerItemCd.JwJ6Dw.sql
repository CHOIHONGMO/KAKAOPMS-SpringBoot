create
    definer = kakaopms@`%` function getBuyerItemCd(gateCd varchar(10), buyerCd varchar(20), itemCd varchar(20)) returns varchar(100) deterministic
BEGIN
    DECLARE returnVal varchar(100);

    SELECT BUYER_ITEM_CD INTO returnVal
      FROM STOCMTGC
     WHERE GATE_CD  = gateCd
       AND BUYER_CD = buyerCd
       AND ITEM_CD  = itemCd
       AND DEL_FLAG = '0'
       AND USE_FLAG = '1';
    
    RETURN returnVal;
END;

