create
    definer = kakaopms@`%` function fn_getSalesUnitPrice(P_GATE_CD varchar(10), P_CUST_CD varchar(10),
                                                         P_DEPT_CD varchar(30), P_APPLY_COM varchar(20),
                                                         P_CONT_NO varchar(20),
                                                         P_CONT_SEQ int) returns decimal(22, 5) deterministic
BEGIN

    DECLARE itemCd       varchar(20);
    DECLARE mgCd         varchar(50);
    DECLARE profitRatio  NUMERIC(22,5) DEFAULT 0; -- 고객사정률
    DECLARE buyUnitPrc   NUMERIC(22,5) DEFAULT 0; -- 매입가
    DECLARE salesUnitPrc NUMERIC(22,5) DEFAULT 0; -- 판가
    DECLARE standUnitPrc NUMERIC(22,5) DEFAULT 0; -- 표준판가

    SELECT getMgInfo(P_GATE_CD, P_CUST_CD, 'CD') into mgCd;
    
    SELECT YNFO.ITEM_CD -- 품목코드
          ,IFNULL(YNFO.CONT_UNIT_PRICE, 0) -- 매입가
          ,IFNULL(YNFO.STD_UNIT_PRICE, 0) INTO itemCd, buyUnitPrc, standUnitPrc -- 표준판가
      FROM STOYINFO YNFO
     WHERE YNFO.GATE_CD   = P_GATE_CD
       AND (YNFO.APPLY_COM= '1000' OR YNFO.APPLY_COM = P_APPLY_COM OR YNFO.APPLY_COM = mgCd)
       AND YNFO.CONT_NO   = P_CONT_NO
       AND YNFO.CONT_SEQ  = P_CONT_SEQ
       AND NOW() BETWEEN YNFO.VALID_FROM_DATE AND YNFO.VALID_TO_DATE
       AND YNFO.DEL_FLAG = '0';

    -- 1. 고객사 판가가 존재
    SELECT
        (CASE WHEN MAX(A.DEPT_PRICE) > 0 THEN MAX(A.DEPT_PRICE)
              ELSE (CASE WHEN MAX(A.ALL_PRICE) > 0 THEN MAX(A.ALL_PRICE)
                         ELSE (CASE WHEN MAX(A.GROUP_PRICE) > 0 THEN MAX(A.GROUP_PRICE)
                                    ELSE 0 END)
                         END)
              END) INTO salesUnitPrc
      FROM (
        SELECT
             (CASE WHEN (UNFO.CUST_CD = P_CUST_CD AND IFNULL(UNFO.DEPT_CD, '*') = P_DEPT_CD) THEN IFNULL(UNFO.SALES_UNIT_PRICE, 0) ELSE 0 END) AS DEPT_PRICE
            ,(CASE WHEN (UNFO.CUST_CD = P_CUST_CD AND IFNULL(UNFO.DEPT_CD, '*') = '*') THEN IFNULL(UNFO.SALES_UNIT_PRICE, 0) ELSE 0 END) AS ALL_PRICE
            ,(CASE WHEN  UNFO.CUST_CD = mgCd THEN IFNULL(UNFO.SALES_UNIT_PRICE, 0) ELSE 0 END) AS GROUP_PRICE
          FROM STOUINFO UNFO
         WHERE UNFO.GATE_CD  = P_GATE_CD
           AND (UNFO.CUST_CD = P_CUST_CD OR UNFO.CUST_CD = mgCd)
           AND (IFNULL(UNFO.DEPT_CD, '*') = P_DEPT_CD OR IFNULL(UNFO.DEPT_CD, '*') = '*')
           AND UNFO.ITEM_CD  = itemCd
           AND UNFO.DEL_FLAG = '0'
      ) A;
    
    -- 2. 고객사 정율로 계산(판가 = 매입가 * 정률)
    IF salesUnitPrc <= 0 THEN
        SELECT IFNULL(CUST.PROFIT_RATIO, 0) INTO profitRatio
          FROM STOCCUST CUST
         WHERE CUST.GATE_CD  = P_GATE_CD
           AND CUST.CUST_CD  = P_CUST_CD
           AND CUST.DEL_FLAG = '0';

        IF profitRatio > 0 THEN
            SELECT buyUnitPrc * (1 + (profitRatio / 100)) INTO salesUnitPrc;
        ELSE
            SELECT standUnitPrc INTO salesUnitPrc;
        END IF;
    END IF;

    SELECT
        (CASE WHEN (P_CUST_CD = CD.CODE OR P_APPLY_COM = CD.CODE) THEN buyUnitPrc
              ELSE salesUnitPrc END) INTO salesUnitPrc
      FROM STOCCODD CD
     WHERE CD.GATE_CD   = P_GATE_CD
       AND CD.CODE_TYPE = 'MP077'
       AND CD.USE_FLAG  = '1'
       AND CD.DEL_FLAG  = '0';

    RETURN ROUND(salesUnitPrc, 0);
end;

