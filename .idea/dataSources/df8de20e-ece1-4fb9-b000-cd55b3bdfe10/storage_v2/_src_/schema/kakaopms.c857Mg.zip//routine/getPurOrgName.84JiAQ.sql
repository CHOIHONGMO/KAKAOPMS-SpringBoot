create
    definer = kakaopms@`%` function getPurOrgName(P_GATE_CD varchar(100), P_BUYER_CD varchar(100),
                                                  P_PUR_ORG_CD varchar(100),
                                                  P_LANG_CD varchar(100)) returns varchar(100) deterministic
BEGIN
 
     DECLARE returnVal  varchar(100);
     
    SELECT 
         case WHEN P_LANG_CD = 'EN' THEN ifnull(STOCOGPU.PUR_ORG_NM, STOCOGPU.PUR_ORG_NM)
              ELSE STOCOGPU.PUR_ORG_NM
         end into returnVal
      FROM STOCOGPU
     WHERE STOCOGPU.GATE_CD = P_GATE_CD
       AND STOCOGPU.PUR_ORG_CD = P_PUR_ORG_CD; 
    
     RETURN returnVal;
END;

