create
    definer = kakaopms@`%` function getGateName(P_GATE_CD varchar(10), P_LANG_CD varchar(20)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);
    
    SELECT
         CASE WHEN P_LANG_CD = 'EN' THEN IFNULL(GATE_NM_ENG, GATE_NM)
              ELSE GATE_NM
         END INTO returnVal
      FROM STOCOGHU
     WHERE GATE_CD = P_GATE_CD;
    
    RETURN returnVal;
END;

