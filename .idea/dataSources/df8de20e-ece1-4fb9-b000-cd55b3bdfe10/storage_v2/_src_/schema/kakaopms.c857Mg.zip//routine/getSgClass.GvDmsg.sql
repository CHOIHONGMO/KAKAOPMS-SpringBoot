create
    definer = kakaopms@`%` function getSgClass(gateCd varchar(10), sgLevel decimal, sgNum varchar(50)) returns varchar(50) deterministic
BEGIN
    DECLARE returnVal  varchar(500);

    SELECT 
        CASE WHEN '1' = sgLevel THEN (SELECT SG_NM FROM STOCSGMT  WHERE GATE_CD = T.GATE_CD AND SG_NUM = T.ITEM_CLS1)
             WHEN '2' = sgLevel THEN (SELECT SG_NM FROM STOCSGMT  WHERE GATE_CD = T.GATE_CD AND SG_NUM = T.ITEM_CLS2)
             WHEN '3' = sgLevel THEN (SELECT SG_NM FROM STOCSGMT  WHERE GATE_CD = T.GATE_CD AND SG_NUM = T.ITEM_CLS3)
             WHEN '4' = sgLevel THEN (SELECT SG_NM FROM STOCSGMT  WHERE GATE_CD = T.GATE_CD AND SG_NUM = T.ITEM_CLS4)
        END  into returnVal
     FROM(
        SELECT
             SGMT.GATE_CD
            , SGMT.SG_NM
            , SGMT.DEPTH
            , SGMT.SG_NUM
            , SGMT.SORT_SQ
            ,(CASE WHEN SGMT.DEPTH = '1' THEN  SGMT.SG_NUM
                   WHEN SGMT.DEPTH = '2' THEN (SELECT dbo.fn_trim(A2.PARENT_SG_NUM) FROM STOCSGMT A2 WHERE  A2.GATE_CD = SGMT.GATE_CD AND A2.DEPTH = '2' AND A2.DEL_FLAG = '0' AND A2.SG_NUM =SGMT.SG_NUM)
                   WHEN SGMT.DEPTH = '3' THEN (SELECT dbo.fn_trim(A2.PARENT_SG_NUM) FROM STOCSGMT A2 WHERE  A2.GATE_CD = SGMT.GATE_CD AND A2.DEPTH = '2' AND A2.DEL_FLAG = '0' AND A2.SG_NUM =(SELECT dbo.fn_trim(A3.PARENT_SG_NUM) FROM STOCSGMT A3 WHERE  A3.GATE_CD = SGMT.GATE_CD AND A3.DEPTH = '3' AND A3.DEL_FLAG = '0' AND A3.SG_NUM =SGMT.SG_NUM))
                   END)  ITEM_CLS1
            ,(CASE WHEN SGMT.DEPTH = '1' THEN  '*'
                   WHEN SGMT.DEPTH = '2' THEN SGMT.SG_NUM
                   WHEN SGMT.DEPTH = '3' THEN (SELECT dbo.fn_trim(A3.PARENT_SG_NUM) FROM STOCSGMT A3 WHERE  A3.GATE_CD = SGMT.GATE_CD AND A3.DEPTH = '3' AND A3.DEL_FLAG = '0' AND A3.SG_NUM =SGMT.SG_NUM)
                   END)  ITEM_CLS2
            ,(CASE WHEN SGMT.DEPTH = '1' THEN  '*'
                   WHEN SGMT.DEPTH = '2' THEN '*'
                   WHEN SGMT.DEPTH = '3' THEN  SGMT.SG_NUM
                   END)  ITEM_CLS3
            , '*'  ITEM_CLS4
        FROM STOCSGMT SGMT
        WHERE SGMT.GATE_CD=gateCd
          AND SGMT.DEL_FLAG='0'
      ) T
    WHERE 1=1
      AND T.SG_NUM = sgNum;
       
       RETURN returnVal;
END;

