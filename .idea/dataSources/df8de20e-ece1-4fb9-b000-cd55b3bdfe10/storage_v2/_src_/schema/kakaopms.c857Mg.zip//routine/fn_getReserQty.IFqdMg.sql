create
    definer = kakaopms@`%` function fn_getReserQty(P_GATE_CD varchar(10), P_CUST_CD varchar(10), P_CONT_NO varchar(20),
                                                   P_CONT_SEQ int) returns decimal(22) deterministic
BEGIN

    DECLARE returnVal NUMERIC(22,0) DEFAULT 0; -- 가용수량
    

    SELECT (SELECT IFNULL(SUM(GBDT.GB_QT),0) - IFNULL(SUM(GIDT.GI_QT),0)
                FROM STOISTDT DT LEFT OUTER JOIN STOIGBDT GBDT ON (GBDT.GATE_CD = STDT.GATE_CD
                                                          AND GBDT.BUYER_CD  = STDT.BUYER_CD
                                                          AND GBDT.GR_NUM  = STDT.DOC_NUM
                                                          AND GBDT.GR_SQ = STDT.DOC_SQ 
                                                          and GBDT.DEL_FLAG ='0')
                        LEFT OUTER JOIN STOIGIDT GIDT ON (GIDT.GATE_CD = GBDT.GATE_CD
                                                          AND GIDT.BUYER_CD = GBDT.BUYER_CD
                                                          AND GIDT.GB_NUM = GBDT.GB_NUM
                                                          AND GIDT.GB_SQ = GBDT.GB_SQ
                                                          AND GIDT.DEL_FLAG = '0')
           WHERE 1=1
           AND DT.GATE_CD = STDT.GATE_CD
           AND DT.BUYER_CD = STDT.BUYER_CD
           AND DT.GR_NUM = STDT.DOC_NUM
           AND DT.GR_SQ = STDT.DOC_SQ ) AS RESER_QT INTO returnVal
          FROM STOISTDT STDT
         WHERE STDT.GATE_CD = P_GATE_CD
           AND STDT.DEL_FLAG = '0'
           AND STDT.BUYER_CD = P_CUST_CD
           AND STDT.GR_NUM = P_CONT_NO
           AND STDT.GR_SQ = P_CONT_SEQ
           AND STDT.SR_TYPE ='GR'
           ;
    
    RETURN ROUND(returnVal, 0);
end;

