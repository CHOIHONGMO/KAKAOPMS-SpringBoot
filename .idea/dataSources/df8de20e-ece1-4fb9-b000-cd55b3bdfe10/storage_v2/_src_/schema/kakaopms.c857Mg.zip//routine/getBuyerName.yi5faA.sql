create
    definer = kakaopms@`%` function getBuyerName(P_GATE_CD varchar(100), P_BUYER_CD varchar(100),
                                                 P_LANG_CODE varchar(100)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);
    
    SELECT
        CASE P_LANG_CODE WHEN 'EN' THEN IFNULL(BUYER_NM_ENG, BUYER_NM)
                         ELSE BUYER_NM
        END INTO returnVal
     FROM STOCOGCM
    WHERE GATE_CD  = P_GATE_CD
      AND BUYER_CD = P_BUYER_CD;
      
    RETURN returnVal;
END;

