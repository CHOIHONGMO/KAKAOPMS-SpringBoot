create
    definer = kakaopms@`%` function getUserInfo(P_GATE_CD varchar(10), P_USER_ID varchar(20),
                                                P_INFO_TYPE varchar(10)) returns varchar(500) deterministic
begin
    
    DECLARE returnVal varchar(500);
    
    SELECT IFNULL(Z.infoData,'') INTO returnVal
      FROM (
        SELECT CASE P_INFO_TYPE
                    WHEN 'USER_NM'     THEN USER_NM
                    WHEN 'PASSWORD'    THEN PASSWORD
                    WHEN 'USER_TYPE'   THEN USER_TYPE
                    WHEN 'WORK_TYPE'   THEN WORK_TYPE
                    WHEN 'POSITION_NM' THEN POSITION_NM
                    WHEN 'DUTY_NM'     THEN DUTY_NM
                    WHEN 'EMAIL'       THEN EMAIL
                    WHEN 'TEL_NUM'     THEN TEL_NUM
                    WHEN 'CELL_NUM'    THEN CELL_NUM
                    WHEN 'FAX_NUM'     THEN FAX_NUM
                    WHEN 'USE_FLAG'    THEN USE_FLAG
                    WHEN 'PROGRESS_CD' THEN PROGRESS_CD
                    WHEN 'BUYER_CD'    THEN COMPANY_CD
                    WHEN 'COMPANY_CD'  THEN COMPANY_CD
                    WHEN 'DEPT_CD'     THEN DEPT_CD
                    ELSE NULL
               END AS infoData
          FROM STOCUSER
         WHERE GATE_CD  = P_GATE_CD
           AND USER_ID  = P_USER_ID
           AND DEL_FLAG = '0'
        UNION
        SELECT CASE P_INFO_TYPE
                    WHEN 'USER_NM'     THEN USER_NM
                    WHEN 'PASSWORD'    THEN PASSWORD
                    WHEN 'USER_TYPE'   THEN USER_TYPE
                    WHEN 'WORK_TYPE'   THEN WORK_TYPE
                    WHEN 'POSITION_NM' THEN POSITION_NM
                    WHEN 'DUTY_NM'     THEN DUTY_NM
                    WHEN 'EMAIL'       THEN EMAIL
                    WHEN 'TEL_NUM'     THEN TEL_NUM
                    WHEN 'CELL_NUM'    THEN CELL_NUM
                    WHEN 'FAX_NUM'     THEN FAX_NUM
                    WHEN 'USE_FLAG'    THEN USE_FLAG
                    WHEN 'PROGRESS_CD' THEN PROGRESS_CD
                    WHEN 'BUYER_CD'    THEN COMPANY_CD
                    WHEN 'COMPANY_CD'  THEN COMPANY_CD
                    WHEN 'DEPT_CD'     THEN DEPT_CD
                    ELSE NULL
               END AS infoData
          FROM STOCCVUR
         WHERE GATE_CD  = P_GATE_CD
           AND USER_ID  = P_USER_ID
           AND DEL_FLAG = '0'
      ) Z
     WHERE 1 = 1
     ;
    
    RETURN returnVal;
END;

