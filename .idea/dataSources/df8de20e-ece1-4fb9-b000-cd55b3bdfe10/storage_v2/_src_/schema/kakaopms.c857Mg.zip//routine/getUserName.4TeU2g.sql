create
    definer = kakaopms@`%` function getUserName(P_GATE_CD varchar(10), P_USER_ID varchar(20),
                                                P_LANG_CD varchar(10)) returns varchar(500) deterministic
begin
    DECLARE returnVal varchar(500);

    SELECT A.USER_NM INTO returnVal
      FROM (
        SELECT CASE WHEN P_LANG_CD = 'EN' THEN IFNULL(STOCUSER.USER_NM_ENG, STOCUSER.USER_NM)
                    ELSE STOCUSER.USER_NM
               END USER_NM
          FROM STOCUSER
         WHERE STOCUSER.GATE_CD = P_GATE_CD
           AND STOCUSER.USER_ID = P_USER_ID
        UNION
        SELECT CASE WHEN P_LANG_CD = 'EN' THEN IFNULL(STOCCVUR.USER_NM, STOCCVUR.USER_NM)
                    ELSE STOCCVUR.USER_NM
               END USER_NM
          FROM STOCCVUR
         WHERE STOCCVUR.GATE_CD = P_GATE_CD
           AND STOCCVUR.USER_ID = P_USER_ID
     ) A limit 1;
    
    RETURN returnVal;
END;

