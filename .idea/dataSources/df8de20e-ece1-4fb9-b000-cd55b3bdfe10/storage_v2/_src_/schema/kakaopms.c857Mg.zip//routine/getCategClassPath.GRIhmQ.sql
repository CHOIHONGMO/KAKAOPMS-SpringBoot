create
    definer = kakaopms@`%` function getCategClassPath(P_GATE_CD varchar(10), P_BUYER_CD varchar(20),
                                                      P_ITEM_CLS1 varchar(50), P_ITEM_CLS2 varchar(50),
                                                      P_ITEM_CLS3 varchar(50),
                                                      P_ITEM_CLS4 varchar(50)) returns varchar(500) deterministic
BEGIN
 
    DECLARE categPath varchar(500);

    SELECT CONCAT(MTC1.ITEM_CLS_NM
                       ,CASE WHEN MTC2.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ', MTC2.ITEM_CLS_NM)
                             ELSE '' END
                       ,CASE WHEN MTC3.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ', MTC3.ITEM_CLS_NM)
                             ELSE '' END
                       ,CASE WHEN MTC4.ITEM_CLS_NM IS NOT NULL THEN CONCAT(' > ', MTC4.ITEM_CLS_NM)
                             ELSE '' END) INTO categPath
      FROM STOCMTCA MTCA
      LEFT OUTER JOIN STOCMTCA MTC1
           ON (MTCA.GATE_CD   = MTC1.GATE_CD
           AND MTCA.BUYER_CD  = MTC1.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC1.ITEM_CLS1
           AND MTC1.ITEM_CLS_TYPE = 'C1'
           AND MTC1.DEL_FLAG  = '0')
      LEFT OUTER JOIN STOCMTCA MTC2
           ON (MTCA.GATE_CD   = MTC2.GATE_CD
           AND MTCA.BUYER_CD  = MTC2.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC2.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC2.ITEM_CLS2
           AND MTC2.ITEM_CLS_TYPE = 'C2'
           AND MTC2.DEL_FLAG  = '0')
      LEFT OUTER JOIN STOCMTCA MTC3
           ON (MTCA.GATE_CD   = MTC3.GATE_CD
           AND MTCA.BUYER_CD  = MTC3.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC3.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC3.ITEM_CLS2
           AND MTCA.ITEM_CLS3 = MTC3.ITEM_CLS3
           AND MTC3.ITEM_CLS_TYPE = 'C3'
           AND MTC3.DEL_FLAG  = '0')
      LEFT OUTER JOIN STOCMTCA MTC4
           ON (MTCA.GATE_CD   = MTC4.GATE_CD
           AND MTCA.BUYER_CD  = MTC4.BUYER_CD
           AND MTCA.ITEM_CLS1 = MTC4.ITEM_CLS1
           AND MTCA.ITEM_CLS2 = MTC4.ITEM_CLS2
           AND MTCA.ITEM_CLS3 = MTC4.ITEM_CLS3
           AND MTCA.ITEM_CLS4 = MTC4.ITEM_CLS4
           AND MTC4.ITEM_CLS_TYPE = 'C4'
           AND MTC4.DEL_FLAG  = '0')
     WHERE MTCA.GATE_CD   = P_GATE_CD
       AND MTCA.BUYER_CD  = P_BUYER_CD
       AND MTCA.USE_FLAG  = '1'
       AND MTCA.DEL_FLAG  = '0'
       AND MTCA.ITEM_CLS1 = P_ITEM_CLS1
       AND MTCA.ITEM_CLS2 = P_ITEM_CLS2
       AND MTCA.ITEM_CLS3 = P_ITEM_CLS3
       AND MTCA.ITEM_CLS4 = P_ITEM_CLS4;

     RETURN categPath;
END;

