create
    definer = kakaopms@`%` function fn_trim(string varchar(4000)) returns varchar(4000) deterministic
BEGIN
    DECLARE value varchar(4000);
    
    SELECT TRIM(string) INTO value;
    
    RETURN value;
END;

