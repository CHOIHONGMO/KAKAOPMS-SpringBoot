create
    definer = kakaopms@`%` function getMgInfo(P_GATE_CD varchar(100), P_BUYER_CD varchar(100),
                                              P_INFO_TYPE varchar(100)) returns varchar(500) deterministic
BEGIN

    DECLARE value varchar(500);

    SELECT
        (CASE WHEN P_INFO_TYPE = 'NM' THEN H.MG_NM ELSE H.MG_CD END) INTO value
      FROM STOCMNGH H
      LEFT JOIN STOCMNGD D
           ON (H.GATE_CD = D.GATE_CD
           AND H.MG_CD = D.MG_CD)
     WHERE H.GATE_CD  = P_GATE_CD
       AND D.CUST_CD  = P_BUYER_CD
       AND H.DEL_FLAG = '0'
       AND H.USE_FLAG = '1'
       AND D.DEL_FLAG = '0'
       AND D.USE_FLAG = '1';

    RETURN value;

END;

