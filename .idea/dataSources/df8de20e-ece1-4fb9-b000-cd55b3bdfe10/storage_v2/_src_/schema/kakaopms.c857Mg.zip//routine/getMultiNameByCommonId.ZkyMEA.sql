create
    definer = kakaopms@`%` function getMultiNameByCommonId(P_GATE_CD varchar(100), P_LANG_CD varchar(100),
                                                           P_COMMON_ID varchar(100),
                                                           P_MULTI_CD varchar(100)) returns varchar(2000) deterministic
BEGIN
    DECLARE value varchar(2000);
    
    SELECT MAX(MULTI_NM) INTO value
      FROM STOCMULG
     WHERE GATE_CD = P_GATE_CD
       AND LANG_CD = P_LANG_CD
       AND COMMON_ID = P_COMMON_ID
       AND MULTI_CD = P_MULTI_CD
       AND DEL_FLAG = '0';
       
     RETURN value;
END;

