create
    definer = kakaopms@`%` function getCodeName(P_GATE_CD varchar(10), P_CODE_TYPE varchar(10), P_CODE varchar(20),
                                                P_LANG_CD varchar(20)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);

    SELECT CODE_DESC INTO returnVal
      FROM STOCCODD
     WHERE GATE_CD  = P_GATE_CD
       AND CODE_TYPE= P_CODE_TYPE
       AND CODE     = P_CODE
       AND LANG_CD  = IFNULL(P_LANG_CD, 'KO')
       AND USE_FLAG = '1'
       AND DEL_FLAG = '0';

    RETURN returnVal;
END;

