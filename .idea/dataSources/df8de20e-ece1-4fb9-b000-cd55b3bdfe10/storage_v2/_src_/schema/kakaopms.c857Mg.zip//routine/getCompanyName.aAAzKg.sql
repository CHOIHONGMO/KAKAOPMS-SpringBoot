create
    definer = kakaopms@`%` function getCompanyName(P_GATE_CD varchar(10), P_COMPANY_CD varchar(20),
                                                   P_LANG_CD varchar(20)) returns varchar(500) deterministic
begin
    DECLARE returnVal VARCHAR(500);
    
    SELECT A.COMPANY_NM INTO returnVal
    FROM  (SELECT
                  CASE WHEN P_LANG_CD = 'EN'
                       THEN IFNULL(VENDOR_NM, VENDOR_NM)
                       ELSE VENDOR_NM
                  END AS COMPANY_NM
           FROM   STOCVNGL
           WHERE  GATE_CD   = P_GATE_CD
           AND    VENDOR_CD = P_COMPANY_CD
           UNION ALL
           SELECT
                  CASE WHEN P_LANG_CD = 'EN'
                       THEN IFNULL(CUST_NM, CUST_NM)
                       ELSE CUST_NM
                  END AS COMPANY_NM
           FROM   STOCCUST
           WHERE  GATE_CD = P_GATE_CD
           AND    CUST_CD = P_COMPANY_CD
           UNION ALL
           SELECT
                  CASE WHEN P_LANG_CD = 'EN'
                       THEN IFNULL(BUYER_NM, BUYER_NM_ENG)
                       ELSE BUYER_NM
                  END AS COMPANY_NM
           FROM   STOCOGCM
           WHERE  GATE_CD  = P_GATE_CD
           AND    BUYER_CD = P_COMPANY_CD
    ) A
    LIMIT 1;
    
    RETURN returnVal;
END;

