create
    definer = kakaopms@`%` function getRfqProgressCd(P_PROGRESS_CD varchar(100), P_CLOSE_DATE datetime) returns varchar(30) deterministic
BEGIN
    DECLARE value varchar(30);
    
    SELECT 
        CASE WHEN CAST(P_PROGRESS_CD AS DECIMAL)  = CAST('100' AS DECIMAL) THEN P_PROGRESS_CD
             WHEN CAST(P_PROGRESS_CD AS DECIMAL) >= CAST('300' AS DECIMAL) THEN P_PROGRESS_CD
             WHEN P_CLOSE_DATE > NOW() THEN P_PROGRESS_CD
             ELSE '300'
        END INTO value
    ;

    RETURN value;
 END;

