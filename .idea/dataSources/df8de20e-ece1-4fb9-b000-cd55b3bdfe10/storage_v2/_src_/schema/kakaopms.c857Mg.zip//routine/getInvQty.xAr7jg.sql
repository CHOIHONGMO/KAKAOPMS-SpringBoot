create
    definer = kakaopms@`%` function getInvQty(P_BUYER_CD varchar(10), P_PO_NUM varchar(20), P_PO_SQ decimal) returns decimal(22, 4) deterministic
BEGIN

    DECLARE returnVal NUMERIC(22,4);

    SELECT IFNULL(SUM(CASE WHEN 'A' IN ('A','B') THEN DT.INV_QT ELSE 0 END), 0) INTO returnVal
      FROM STOPIVHD HD
      JOIN STOPIVDT DT
           ON (DT.GATE_CD   = HD.GATE_CD
           AND  DT.BUYER_CD  = HD.BUYER_CD
           AND  DT.INV_NUM  = HD.INV_NUM
           AND  DT.DEL_FLAG = '0')
     WHERE HD.PROGRESS_CD IN ('6100','6120','7100','7120')
       AND HD.DEL_FLAG = '0'
       and DT.BUYER_CD = P_BUYER_CD
       AND DT.PO_NUM   = P_PO_NUM
       AND DT.PO_SQ    = P_PO_SQ;

    RETURN returnVal;

END;

