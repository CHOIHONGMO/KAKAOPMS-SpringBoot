create
    definer = kakaopms@`%` function getCustInfo(P_GATE_CD varchar(100), P_CUST_CD varchar(100),
                                                P_INFO_TYPE varchar(100)) returns varchar(2000) deterministic
BEGIN

    DECLARE value varchar(2000);
    
    SELECT
        CASE P_INFO_TYPE
            WHEN 'CUST_NM' THEN CUST_NM
            WHEN 'HQ_ADDR_1' THEN ADDR1
            WHEN 'HQ_ADDR_2' THEN ADDR2
            WHEN 'HQ_ZIP_CD' THEN ZIP_CD
            WHEN 'CEO_USER_NM' THEN CEO_USER_NM
            WHEN 'TEL_NO' THEN TEL_NUM
            WHEN 'FAX_NO' THEN FAX_NUM          
            WHEN 'IRS_NO' THEN IRS_NUM
            WHEN 'IRS_SUB_NO' THEN IRS_SUB_NUM
            WHEN 'INDUSTRY_TYPE' THEN INDUSTRY_TYPE
            WHEN 'BUSINESS_TYPE' THEN BUSINESS_TYPE
            WHEN 'COMPANY_REG_NO' THEN COMPANY_REG_NUM
            ELSE ''
        END INTO value
      FROM STOCCUST
     WHERE GATE_CD  = P_GATE_CD
       AND CUST_CD  = P_CUST_CD
       AND DEL_FLAG = '0';
    
    RETURN value;
END;

