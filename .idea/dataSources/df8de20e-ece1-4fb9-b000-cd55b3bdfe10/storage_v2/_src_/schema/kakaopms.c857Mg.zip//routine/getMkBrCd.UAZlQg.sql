create
    definer = kakaopms@`%` function getMkBrCd(gateCd varchar(10), buyerCd varchar(10), mkbrType varchar(30),
                                              mkbrNm varchar(30)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);

    SELECT MKBR_CD INTO returnVal
      FROM STOCMKBR
     WHERE GATE_CD   = gateCd
       and BUYER_CD  = buyerCd
       AND MKBR_TYPE = mkbrType
       AND MKBR_NM   = mkbrNm;

    RETURN returnVal;
END;

