create
    definer = kakaopms@`%` function getItemClsCd(P_GATE_CD varchar(10), P_BUYER_CD varchar(20), P_ITEM_CD varchar(30),
                                                 P_CLS_TYPE varchar(20),
                                                 P_CLS_NO varchar(20)) returns varchar(500) deterministic
BEGIN
    DECLARE returnVal varchar(500);
    
    SELECT A.ITEM_CLS INTO returnVal
      FROM (
        SELECT 
            (CASE WHEN P_CLS_NO = '1' THEN ITEM_CLS1 WHEN P_CLS_NO = '2' THEN ITEM_CLS2 WHEN P_CLS_NO = '3' THEN ITEM_CLS3 ELSE ITEM_CLS4 END) AS ITEM_CLS
          FROM STOCMTGC
         WHERE GATE_CD  = P_GATE_CD
           AND BUYER_CD = P_BUYER_CD
           AND ITEM_CD  = P_ITEM_CD
           AND DEL_FLAG = '0'
         ORDER BY BUYER_CD ASC, ITEM_CLS1 ASC, ITEM_CLS2 ASC, ITEM_CLS3 ASC, ITEM_CLS4 ASC
    ) A 
    LIMIT 1;
    
    RETURN returnVal;
END;

