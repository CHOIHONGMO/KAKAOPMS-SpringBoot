create
    definer = kakaopms@`%` function getDeptName(gateCd varchar(3), buyerCd varchar(10), deptCd varchar(30),
                                                langCd varchar(2)) returns varchar(500) deterministic
BEGIN

    DECLARE returnVal varchar(500);
    
    SELECT
          CASE WHEN langCd = 'EN' THEN IFNULL(DEPT_NM_ENG, DEPT_NM)
               ELSE DEPT_NM
          END INTO returnVal
      FROM STOCOGDP
     WHERE GATE_CD  = gateCd
       AND BUYER_CD = buyerCd
       AND DEPT_CD  = deptCd
     LIMIT 1;
     
     RETURN returnVal;
END;

