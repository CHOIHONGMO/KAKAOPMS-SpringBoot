create
    definer = kakaopms@`%` function getFileCount(P_GATE_CD varchar(10), P_UUID varchar(50)) returns varchar(100) deterministic
BEGIN

    DECLARE returnVal varchar(100);
    
    SELECT COUNT(*) INTO returnVal
      FROM STOCATCH
     WHERE GATE_CD  = P_GATE_CD
       AND UUID     = P_UUID
       AND DEL_FLAG = '0';
    
    RETURN returnVal;
END;

