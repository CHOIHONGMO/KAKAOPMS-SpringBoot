create
    definer = kakaopms@`%` function fn_GetTotalWorkingDaysFromParamDate(fromDate datetime, DateCnt int) returns datetime deterministic
BEGIN

    DECLARE rtnDate         DATETIME;
    DECLARE TotWorkingDays  INT;
 
    SET fromDate = DATE_FORMAT(CAST(fromDate AS CHAR), '%Y%m%d');
    SET rtnDate  = fromDate;
    
    WHILE TotWorkingDays <= DateCnt DO
        BEGIN
             IF DAYOFWEEK(rtnDate) IN (2, 3, 4, 5, 6) THEN
                 BEGIN
                     SET TotWorkingDays = TotWorkingDays + 1;
                 END;
             END IF;
             
             IF (SELECT COUNT(*) FROM STOCHLDM
                  WHERE GATE_CD  = '100'
                    AND DEL_FLAG = '0'
                    AND ATTEND_CD != '1'
                    AND HOLYDAY = DATE_FORMAT(rtnDate, '%Y%m%d')) > 0 THEN
                 
                 BEGIN
                     SET TotWorkingDays = TotWorkingDays - 1;
                 END;
             END IF;
             
             SET rtnDate = ADDDATE(rtnDate, INTERVAL 1 DAY);
        END;
    END WHILE;
    
    IF TotWorkingDays > DateCnt THEN
        BEGIN
            SET rtnDate = ADDDATE(rtnDate, INTERVAL -1 DAY);
        END;
    END IF;
    
    RETURN rtnDate;
END;

